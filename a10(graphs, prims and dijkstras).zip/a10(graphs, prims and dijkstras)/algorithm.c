/*
 -------------------------------------
 File:    algorithm.c
 Project: A10T3
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2021-04-07
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "heap.h"
#include "algorithm.h"

/* Compute and return MST by Prim's algorithm using priority queue (min-heap)
 * @param g     - graph by reference
 * @param start - the root node of MST
 * @return      - pointer of edge list of shortest path tree
 */
EDGELIST* mst_prim(GRAPH *g, int start) {
	//if no graph return null
	if (g == NULL)
		return NULL;

	int i, heapindex, n = g->order;
	int T[n], parent[n];
	HNODE hn;
	//label all nodes inside the T array
	for (i = 0; i < n; i++) {
		T[i] = 0;
		parent[i] = -1;
	}

	HEAP *h = new_heap(4);
	//get neighbors of root
	ADJNODE *temp = g->nodes[start]->neighbor;
	T[start] = 1;
	//add all neighbors of root node to heap
	while (temp) {
		hn.key = temp->weight;
		hn.data = temp->nid;
		insert(h, hn);
		parent[temp->nid] = start;
		temp = temp->next;
	}
	//initialize an edgelist to hold the mst
	EDGELIST *mst = new_edgelist();
	//add all edges to the mst
	//heap will store at most 4 values (in this example) since there will never be duplicate nodes added
	//any time a duplicate node is added instead of actually inserting it you just decrease_key
	while (h->size > 0) {
		//take the minimum edge from G connected to nodes already in mst
		hn = extract_min(h);
		i = hn.data;
		T[i] = 1;
		//add this edge to the mst
		add_edge_end(mst, parent[i], i, hn.key);
		//add all neighbors of this new node to the heap
		temp = g->nodes[i]->neighbor;
		while (temp) {
			//find the node in the heap
			heapindex = find_index(h, temp->nid);
			//if the node is in the heap then relax it
			if (heapindex >= 0) {
				if (T[temp->nid] == 0
						&& temp->weight < h->hnap[heapindex].key) {
					decrease_key(h, heapindex, temp->weight);
					parent[temp->nid] = i;
				}
			} else {
				if (T[temp->nid] == 0) {
					hn.key = temp->weight;
					hn.data = temp->nid;
					insert(h, hn);
					parent[temp->nid] = i;
				}
			}
			temp = temp->next;
		}
	}
	return mst;
}
/*
 * Compute shortest path tree as edge list by Dijkstra's algorithm using priority queue (min-heap)
 * @param g     - graph by reference
 * @param start - the root node of shortest path tree
 * @return      - pointer of edge list of shortest path tree
 */
EDGELIST* spt_dijkstra(GRAPH *g, int start) {
	//if there is no graph then return null
	if (!g)
		return NULL;
	//create a new edgelist to represent the tree
	EDGELIST *spt = new_edgelist();
	//n will be the number of nodes (the order of the graph)
	int i, heapindex, n = g->order;
	//parent array will be for backtracking
	int T[n], parent[n], label[n];
	HNODE hn;
	//make an array T to hold the nodes, give them values from 0 to n (their nid)
	//make an array label to represent the weight of node i from root node
	for (i = 0; i < n; i++) {
		T[i] = 0;
		label[i] = INFINITY;
	}
	//create a new heap that can initially hold 4 objects
	HEAP *h = new_heap(4);
	//look at the first neighbor of the start node (root of the tree)
	ADJNODE *temp = g->nodes[start]->neighbor;
	//assign the root node the proper nid and weight
	label[start] = 0;
	T[start] = 1;
	//insert all of the root nodes' neighbors into a heap
	while (temp) {
		//the key of the nodes will be the distance from the root node to it, this will be used for sorting
		hn.key = temp->weight + label[start];
		//the data will be the nodes id
		hn.data = temp->nid;
		//insert the node into the heap
		insert(h, hn);
		//the parent of the neighbor is the original root node
		parent[temp->nid] = start;
		//do this for each neighbor of the root node
		temp = temp->next;
	}
	//evaluate each node inside the hash table
	while (h->size > 0) {
		//get the min node (shortest path from root)
		hn = extract_min(h);
		i = hn.data;
		//update T and label arrays with min node values
		T[i] = 1;
		label[i] = hn.key;
		//add the edge from root to min into the spt
		add_edge_end(spt, parent[i], i, label[i] - label[parent[i]]);
		//relax any nodes connected to the min node
		temp = g->nodes[i]->neighbor;

		while (temp) {
			heapindex = find_index(h, temp->nid);
			//if node is already in heap then relax it
			if (heapindex >= 0) {
				if (T[temp->nid] == 0
						&& temp->weight + label[i] < h->hnap[heapindex].key) {
					decrease_key(h, heapindex, temp->weight + label[i]);
					parent[temp->nid] = i;//update parent array for min node's neighbors
				}
			} else {
				//add new nodes to hash table if they weren't there before
				if (T[temp->nid] == 0) {
					hn.key = temp->weight + label[i];
					hn.data = temp->nid;
					insert(h, hn);
					parent[temp->nid] = i;
				}
			}
			//do this for each neighbor
			temp = temp->next;
		}
	}
	return spt;

}

/*
 * Compute shortest path as edge list by Dijkstra's algorithm using priority queue (min-heap)
 * @param g     - graph by reference
 * @param start - the start node of shortest path
 * @param end   - the end node of shortest path
 * @return      - pointer of edge list of shortest path
 */
EDGELIST* sp_dijkstra(GRAPH *g, int start, int end) {
	//if there is no graph then just return null
	if (g == NULL)
		return NULL;
	EDGELIST *spt = new_edgelist();
	int i, heapindex, n = g->order;
	int T[n], parent[n], label[n];
	int found = 0; //boolean variable to represent if search node has been found yet
	HNODE hn;
	//set T array up with all nodes in graph and their corresponding nids
	//set label array up to initially give all nodes a distance of infinity away from the root node
	for (i = 0; i < n; i++) {
		T[i] = 0;
		label[i] = INFINITY;
	}
	//instantiate a heap to use as a priority queue
	HEAP *h = new_heap(4);
	//get the first neighbor of start (root node)
	ADJNODE *temp = g->nodes[start]->neighbor;

	label[start] = 0;
	T[start] = 1;
	//insert all of the root nodes' neighbors into the heap
	while (temp) {
		hn.key = temp->weight + label[start];
		hn.data = temp->nid;
		insert(h, hn);
		parent[temp->nid] = start;
		temp = temp->next;
	}

	//extract min node and repeat process (greedy algorithm)
	while (h->size > 0 && found == 0) {
		hn = extract_min(h);
		i = hn.data;
		//check if the min nodes' nid matches the one we are searching for
		if (hn.key == end) {
			found = 1;
		}
		//add edge to tree
		T[i] = 1;
		label[i] = hn.key;
		add_edge_end(spt, parent[i], i, label[i] - label[parent[i]]);
		//relax nodes
		temp = g->nodes[i]->neighbor;

		while (temp) {
			heapindex = find_index(h, temp->nid);
			//if node is already in heap then relax it
			if (heapindex >= 0) {
				if (T[temp->nid] == 0
						&& temp->weight + label[i] < h->hnap[heapindex].key) {
					decrease_key(h, heapindex, temp->weight + label[i]);
					parent[temp->nid] = i;
				}
			} else {
				if (T[temp->nid] == 0) {
					hn.key = temp->weight + label[i];
					hn.data = temp->nid;
					insert(h, hn);
					parent[temp->nid] = i;
				}
			}
			temp = temp->next;
		}

	}

	//now with shortest path tree created, back track through it to find the shortest path from end to start
	EDGELIST *sp = new_edgelist();
	i = end;
	while (1) {
		if (i == start)
			break;
		add_edge_start(sp, parent[i], i, label[i] - label[parent[i]]);
		i = parent[i];
	}
	return sp;
}
