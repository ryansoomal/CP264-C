/*
 -------------------------------------
 File:    edgelist.c
 Project: A10T1
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2021-04-06
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "edgelist.h"

EDGELIST* new_edgelist() {
	EDGELIST *el = (EDGELIST*) malloc(sizeof(EDGELIST));
	el->size = 0;
	el->start = NULL;
	el->end = NULL;
	return el;
}
/* add an new edge at the end of the linked list of edges*/
void add_edge_end(EDGELIST *g, int from, int to, int weight) {
	//make edge
	EDGE *new_edge = (EDGE*) malloc(sizeof(EDGE));
	new_edge->from = from;
	new_edge->to = to;
	new_edge->weight = weight;
	new_edge->next = NULL;
	//add edge to list
	if (g->start == NULL) {
		g->start = new_edge;
	} else
		g->end->next = new_edge;
	g->end = new_edge;
	g->size++;

}

void add_edge_start(EDGELIST *g, int from, int to, int weight) {
	//make edge
	EDGE *new_edge = (EDGE*) malloc(sizeof(EDGE));
	new_edge->from = from;
	new_edge->to = to;
	new_edge->weight = weight;
	new_edge->next = NULL;
	//add edge to list
	if (g->end == NULL) {
		g->end = new_edge;
	} else
		new_edge->next = g->start;
	g->start = new_edge;
	g->size++;
}
/* get weight of the edge list graph*/
int weight_edgelist(EDGELIST *g) {
	EDGE *curr = (EDGE*) malloc(sizeof(EDGE));

	curr = g->start;
	int weight = 0;
	while (curr != NULL) {
		weight += curr->weight;
		curr = curr->next;
	}

	return weight;
}

void clean_edgelist(EDGELIST **gp) {
	EDGELIST *g = *gp;
	EDGE *temp, *p = g->start;
	while (p) {
		temp = p;
		p = p->next;
		free(temp);
	}
	free(g);
	*gp = NULL;
}

void display_edgelist(EDGELIST *g) {
	if (g == NULL)
		return;
	printf("size:%d\n", g->size);
	printf("(from to weight):");
	EDGE *p = g->start;
	while (p) {
		printf("(%d %d %d) ", p->from, p->to, p->weight);
		p = p->next;
	}
}
