/*
 -------------------------------------
 File:    fibonacci.h
 Project: Fibonacci
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2021-01-26
 -------------------------------------
 */
extern int *la; //global pointer varaible to get local variable address
/**
 * Computes the nth fibonacci number iteratively, keeps track of two vars to do this
 * @param n, the nth term
 * @return fib, the nth fibonacci number
 */
int iterative_fibonacci(int n) {
	if (&n < la)
		la = &n;
	//define two local vars
	int one = 1;
	int two = 1;
	int i = 1; //number counter
	int temp;
	while (i < n) {
		temp = two;
		two = one + two;
		one = temp;
		i++;
	}
	return one;

}
/**
 * computes the nth fibonacci number recursively
 * @param n, the nth term
 * @return the nth fibonacci number
 */
int recursive_fibonacci(int n) {
	if (&n < la)
		la = &n;
	if(n<=0){
		return 0;
	}
	else if (n == 1 || n == 2) {
		return 1;
	} else {
		return recursive_fibonacci(n - 1) + recursive_fibonacci(n - 2);
	}
}
