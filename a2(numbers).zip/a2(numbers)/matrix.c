/*
 ============================================================================
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include "matrix.h"
/**
 * Displays the n by n matrix in 2D style
 * @param m first element pointer
 * @param n, dimension of matrix
 */
void display_matrix(int *m, int n) {
	int *p = m, i, j;
	for (i = 0; i < n; i++) {
		printf("\n");
		for (j = 0; j < n; j++) {
			printf("%4d", *p++);
		}
	}
	printf("\n");
}

/**
 * computes and returns the sum of all elements of teh n by n matrix m
 * @param m, first element pointer
 * @param n, dimensions
 * @return
 */
int sum(int *m, int n) {
	int total = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			total += *m++;
		}
	}

	return total;
}

/**
 * Computers and returns if the n by n matrix is a magic square
 * @param m, pointer to first element
 * @param n, size of matrix
 * @return 1 if true, 0 otherwise
 */
int is_magic_square(int *m, int n) {
	int total = 0;
	int is_magic = 1;
	int temp = 0;
	int i, j;
	//sum each row
	for (i = 0; i < n; i++) {
		temp = 0;
		for (j = 0; j < n; j++) {
			temp += *m;
			m++;
		}
		if (i == 0)
			total = temp;
		else {
			if (total != temp) {
				is_magic = 0;
				break;
			}

		}
	}

	//sum each column
	if (is_magic == 1) {
		m -= n * n; //reset pointer
		for (i = 1; i <= n; i++) {
			temp = 0;
			for (j = 0; j < n; j++) {
				temp += *m;
				m += n;
			}
			if (i == 0)
				total = temp;
			else {
				if (total != temp) {
					is_magic = 0;
					break;
				}
			}
			m -= (n * n);
			m++;
		}
	}

	//sum diagonal one
	if (is_magic == 1) {
		m -= n; //reset pointer
		temp = 0; //reset temp
		for (i = 1; i <= n; i++) {
			temp += *m;
			m += (n + 1);
		}
		if (temp != total) {
			is_magic = 0;
		}
	}

	//sum diagonal two
	if (is_magic == 1) {
		//reset pointer
		m -= (n + 1);
		m -= ((n * n) - 1);
		//move pointer to opposite corner
		m += n - 1;
		//reset temp
		temp = 0;
		for (i = 1; i <= n; i++) {
			temp += *m;
			m += (n - 1);
		}
		if (temp != total) {
			is_magic = 0;
		}

	}
	return is_magic;
}
/**
 * Transposes the n by n matrix m1 and saves the result in m2
 * @param m1, starting matrix pointer
 * @param m2, resultant matrix pointer
 * @param n, size
 */
void transpose_matrix(int *m1, int *m2, int n) {
	int i, j;

	for (i = 1; i <= n; i++) {
		for (j = 0; j < n; j++) {
			*m2 = *m1;
			m1 += n;
			m2++;
		}
		m1 -= (n * n);
		m1++;
	}

}

/**
 * multiplies one row of matrix m1 with one column of matrix m2
 * @param m1, pointer to m1, moves left to right
 * @param m2, pointer to m2, moves top to bottom
 * @param n, size of matrices
 * @return row-col sum-product
 */
int multiply_row_col(int *m1, int *m2, int n) {
	//this function does the math for ONE row and ONE column
	int sum = 0;

	for (int i = 0; i < n; i++) {

		sum += (*m1) * (*m2);
		m1++;
		m2 += n;
	}
	return sum;
}

/**
 * Computers the matrix multiplication m1*m2 and saves the resulted matrix in m3
 * @param m1, pointer to m1
 * @param m2, pointer to m2
 * @param m3, pointer to m3
 * @param n, size of matrices
 */
void multiply_matrix(int *m1, int *m2, int *m3, int n) {
	//this function moves the pointers to the right spot, the other one does the math
	for (int i = 0; i < n; i++) {

		for (int j = 0; j < n; j++) {
			*m3 = multiply_row_col(m1, m2, n);
			m2++;
			m3++;
		}
		//move m1 to next row, put m2 back at first column
		m1 += n;
		m2 -= n;
	}

}

