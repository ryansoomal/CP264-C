/*
 -------------------------------------
 File:    matrix.h
 Project: Matrix
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2021-01-27
 -------------------------------------
 */
void display_matrix(int *m, int n);
int sum(int *m, int n);
int is_magic_square(int *m, int n);
void transpose_matrix(int *m1, int *m2, int n);
void multiply_matrix(int *m1, int *m2, int *m3, int n);
