/*
 -------------------------------------
 File:    mystring.c
 Project: Mystring
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2021-02-02
 -------------------------------------
 */
#include "mystring.h"
#define NULL 0
#define  cBlank   ' '
/**
 * computes and returns the number of characters of string passed by s (including space)
 * @param s, input string
 * @return number of chars
 */
int str_length(char *s) {
	if (s == NULL)
		return -1;
	int counter = 0;
	while (*s) {
		counter++;
		s++;
	}
	return counter;
}

/**
 * computes and returns the number of words of string passed by s
 * @param s, input string
 * @return number of words
 */
int word_count(char *s) {
	//algorithm: each time you find a letter, add one to the count and then go through the whole word until you find a space
	if (s == NULL)
		return -1;
	int counter = 0;
	int flag = 0;
	while (*s) {
		if (*s != cBlank && flag == 0) { //letter found
			counter++;
			flag = 1;
		} else if (*s == cBlank) {
			//space found
			flag = 0;
		}
		s++;

	}
	return counter;
}

/**
 * changes upper case to lower case of string passed by s
 * @param s
 */
void lower_case(char *s) {
	if (s == NULL)
		return;
	while (*s) {
		if (*s >= 'A' && *s <= 'Z') {
			*s += 32;
		}
		s++;
	}
	return;
}

/**
 * removes the non necessary empty spaces of string passed by s
 * @param s, input string
 */
void trim(char *s) {
	//algorithm: go through s until you find a space, flip the flag and the delete every space after that until you find a char, then flip the flag again
	//the number of spaces actually required is the number of words
	//only start adding spaces once the first word has been found
	int space_found = 0;
	int word_found = 0;
	int writer = 0, reader = 0;
	if (s == NULL)
		return;
	while (s[reader]) {
		if (s[reader] == cBlank && space_found == 0 && word_found == 1) { //first space found
			space_found = 1; //flag flipped
			s[writer] = s[reader];
			writer++;

		} else if (s[reader] != cBlank) {
			//start of word found
			space_found = 0; //flag flipped
			s[writer] = s[reader];
			writer++;
			word_found = 1; //now safe to start adding spaces

		}
		reader++;

	}
	//check if last char is a space and remove it if it is
	if (s[writer - 1] == cBlank) {
		s[writer - 1] = '\0';
	} else {
		s[writer] = 0; //denote end of string
	}

}
