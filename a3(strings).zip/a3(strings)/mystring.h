/*
 -------------------------------------
 File:    mystring.h
 Project: Mystring
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2021-02-02
 -------------------------------------
 */
#ifndef MYSTRING_H_
#define MYSTRING_H_

int str_length(char*);
int word_count(char*);
void lower_case(char*);
void trim(char*);

#endif /* MYSTRING_H_ */
