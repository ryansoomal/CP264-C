/*
 -------------------------------------
 File:    myword.c
 Project: Myword
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2021-02-02
 -------------------------------------
 */

#include <stdio.h>
#include <string.h>
#include "mystring.h"
#include "myword.h"

/**
 * reads stop words from the common word file by filename and puts them in the stop word dictionary
 * structure as an array of 26 strings, one for each letter of the alphabet
 * the array of strings is passed parameter char *stopwords[], stopwords[i] holds the pointer of the i-th string
 * @param filename, a pointer to the file
 * @param stopwords
 */
void set_stopword(char *filename, char *stopwords[]) {
	//algorithm: read stop words from file and insert stop words into stopwords[]
	char line[1000];
	char delimiters[] = ".,\n\t\r";
	char *token;
	int i;
	FILE *fp;
	fp = fopen(filename, "r");
	if (fp == NULL) {
		perror("error opening file");
	}

	while (fgets(line, 1000, fp) != NULL) { //reads up to 1000 chars on the line in filename and stores them in line
		//token will hold a pointer to the first token found in line
		token = (char*) strtok(line, delimiters); //breaks string line into a series of tokens broken up by delimiters specified
		while (token != NULL) { //loop through all tokens from the line
			i = (int) (*token - 'a'); //subtract a to get the alphabet index
			//append both the token and a comma to the stopwords array at the proper letter index
			strcat(stopwords[i], token);
			strcat(stopwords[i], ",");
			token = (char*) strtok(NULL, delimiters); //move pointer to the next token
		}
	}
}

// this function check if word is a word in string str,
// returns 1 if yes, 0 otherwise
int contain_word(char *str, char *word) {
	//cases:
	//1. word is not a stop word
	//2. word is the first stopword in stopwords[i] so the substring would be word,
	//3. word is in the middle of stopwords[i] so the substring would be ,word,
	//4. word is the last word in stopwords[i] so the substring would be ,word
	//checking if ,word, is contained in the substring will sometimes return the wrong result so the code HBF gave us wont always work
	char case1[20] = "";
	char case2[20] = "";
	char case3[20] = "";
	char case4[20] = "";
	//case 1
	strcat(case1, word);
	if (strstr(str, case1)) {
		//the word is a stop word, test three cases
		//case 2
		strcat(case2, word);
		strcat(case2, ",");
		//case 3
		strcat(case3, ",");
		strcat(case3, word);
		strcat(case3, ",");
		//case 4
		strcat(case4, ",");
		strcat(case4, word);
		//if any of the following are contained then it is a valid substring
		return strstr(str, case2) || strstr(str, case3) || strstr(str, case4);
	} else {
		return 0;
	}

}

// this function check if the word is contained in directory stopwords[]
// returns 1 if yes, 0 otherwise. It use function contain_word()
int is_stopword(char *stopwords[], char *word) {
	if (word == NULL || *word == '\0') {
		return 0;
	}

	else {
		return contain_word(stopwords[*word - 'a'], word);
	}
}

/**
 * opens and reads a test file of name passed by *filename line by linem it gets each word
 * if it is not a stop word, check if it is alread in array words ->word_array, if yes, increases
 * its frequency by 1, otherwise inserts it to the end of the word_array and sets its frequency
 * to 1. Meantime, it updates the count information
 * @param filename
 * @param ws
 * @param stopwords
 * @return
 */
int process_word(char *filename, WORDSUMMARY *ws, char *stopwords[]) {
	const char delimiters[] = " .,;:!()&?-\n\t\r\"\'";
	char line[MAX_LINE_LEN];
	char *token;
	int i;

	FILE *fp;
	int exists = 0;
	fp = fopen(filename, "r");

	if (fp == NULL)
		perror("error opening file");

	while (fgets(line, MAX_LINE_LEN, fp) != NULL) {
		ws->line_count++;
		lower_case(line);
		trim(line);
		token = (char*) strtok(line, delimiters);

		while (token != NULL) {
			//printf("currently checking token: %s\n", token);
			if (contain_word(stopwords[*token - 'a'], token) == 0) {
				//printf("%s is not a stop word\n", token);
				//not a stop word

				exists = 0; //reset exists
				i = 0; //reset loop var
				//see if word is already in ws
				while (i <= ws->keyword_count && exists == 0) {
					//printf("while loop entered: i=%d\n", i);
					//printf("word array[i] = %s\n", ws->word_array[i].word);
					if (strcmp(ws->word_array[i].word, token) == 0) {
						//word already in array
						exists = 1;
						ws->word_array[i].frequency++;

					} else {
						i++;
					}
				}
				if (exists == 0) {
					//make a new word to add to the array
					WORD temp;
					strcpy(temp.word, token);
					temp.frequency = 1;
					//add temp to list of words
					ws->word_array[ws->keyword_count] = temp;
					ws->keyword_count++;
				}

			}
			ws->word_count++;
			token = (char*) strtok(NULL, delimiters); //next word
		}

	}
	return 0;
}

int save_to_file(char *filename, WORDSUMMARY *ws) {
	FILE *fp = fopen(filename, "w");
	fprintf(fp, "%s:%d\n", "line count", ws->line_count);
	fprintf(fp, "%s:%d\n", "word count", ws->word_count);
	fprintf(fp, "%s:%d\n", "non-common word count", ws->keyword_count);
	int i;
	for (i = 0; i < ws->keyword_count; i++) {
		fprintf(fp, "%s:%d\n", ws->word_array[i].word,
				ws->word_array[i].frequency);
	}
}

