/*
 -------------------------------------
 File:    myrecord.c
 Project: myrecord
 A4
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2021-02-11
 -------------------------------------
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "myrecord.h"

#define MAX_LINE 100

/**
 * this function converts a float score to a letter grade according to ranges
 * S=[90,100], A=[80,90), B=[70,80), C=[60, 70), D=[50,60), F=[0,50), and returns the letter grade.
 * @param s, float grade
 * @return letter corresponding to grade
 */
char letter_grade(float s) {
	char grade = 'F';
	if (s >= 90 && s <= 100)
		grade = 'S';

	else if (s >= 80 && s < 90)
		grade = 'A';

	else if (s >= 70 && s < 80)
		grade = 'B';

	else if (s >= 60 && s < 70)
		grade = 'C';

	else if (s >= 50 && s < 60)
		grade = 'D';

	return grade;
}

/**
 * this function imports data from file of name passed by filename, and stores all record entries
 * in an array of RECORD dataset[] and returns the number of records read
 * @param dataset
 * @param filename
 * @return, number of records read
 */
int import_data(RECORD dataset[], char *filename) {
	char line[100];
	char delimiters[] = ",\n\r";
	char *token;
	int i = 0; //record counter
	//open file
	FILE *fp;
	fp = fopen(filename, "r");
	if (fp == NULL) {
		perror("error opening file");
	}

	while (fgets(line, 1000, fp) != NULL) { //reads up to 100 chars on the line in filename and stores them in line
		//token will hold a pointer to the first token found in line
		token = (char*) strtok(line, delimiters); //breaks string line into a series of tokens broken up by delimiters specified
		//add attributes record stored at index i
		strcpy(dataset[i].name, token);
		token = (char*) strtok(NULL, delimiters); //move pointer to the next token
		dataset[i].score = atof(token);
		i++;
	}

	return i;
}
/**
 * this function computes the average score, and standard deviation of the score values of dataset[], and
 * returns the results by the RECORD type. It also outputs name and letter grade to file of name passed by
 * filenamem using format "%s, %c\n'
 * @param dataset, records
 * @param n, count
 * @param filename, file to output to
 * @return
 */
REPORT report_data(RECORD dataset[], int n, char *filename) {
	//initialize a report
	REPORT report = { };
	if (n < 1)
		return report;
	//open a file for writing
	FILE *fp = fopen(filename, "w");
	//loop through dataset to calculate mean and stddev
	int i = 0;
	float total = 0;
	for (i = 0; i < n; i++) {
		fprintf(fp, "%s,%c\n", dataset[i].name, letter_grade(dataset[i].score));
		total += dataset[i].score;
	}
	//compute mean
	float mean = total / n;
	//computer standard deviation
	float std = 0;
	for (i = 0; i < n; i++) {
		std += (dataset[i].score - mean) * (dataset[i].score - mean);
	}
	std = sqrt(std / n);
	//add attributes to report and return it
	report.count = n;
	report.mean = mean;
	report.stddev = std;
	return report;
}
