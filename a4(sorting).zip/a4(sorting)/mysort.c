/*
 -------------------------------------
 File:    mysort.h
 Project: mysort
 A4
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2021-02-09
 -------------------------------------
 */

#include "mysort.h"
#include <stdio.h>

/**
 * checks if the array is sorted in increasing order in the subarray between left and right
 * @param a, array
 * @param left, leftmost to look at
 * @param right, rightmost element to look at
 * @return true if sorted else false
 */
BOOLEAN is_sorted(int *a, int left, int right) {
	BOOLEAN is_sorted = TRUE;
	int i = 0; //start an index counter
	//point a at the first element to check
	while (i < left) {
		a++;
		i++;
	}
	//check sorted
	int *prev;
	while (is_sorted == TRUE && i < right) {
		prev = a;
		a++;
		if (*prev > *a) {
			is_sorted = FALSE;
		}
		i++;
	}
	return is_sorted;
}

void select_sort(int *a, int left, int right) {
	int x = 0;
	int *ptr;	//temp pointer
	int *smallest;
	int j = 0;
	//point a at the first element to check
	while (x < left) {
		a++;
		x++;
	}
	//algorithm: start at left and then find the smallest value in the array, swap them then increment left by one
	while (x < right) {
		ptr = a;
		j = x;
		smallest = ptr;
		while (j <= right) {
			if (*ptr < *smallest) {
				smallest = ptr;
			}
			ptr++;
			j++;
		}
		if (*smallest != *a) {
			swap(smallest, a);
		}

		a++;
		x++;
	}
}
/**
 * auxiliary function used by quicksort function
 * @param left
 * @param right
 * @return j, pivot element
 */

int partition(int *a, int left, int right) {
	BOOLEAN flag = FALSE;
	int first = left; //left index
	int last = right + 1; //right index

	//use the first element as the pivot
	int pivot = a[left];
	//find two elements to swap around pivot
	while (flag != TRUE) {
		//find an element larger than pivot
		while (a[++first] < pivot) {
			if (first == right)
				flag = TRUE;
		}
		//find an element smaller than pivot
		while (a[--last] > pivot) {
			if (last == left)
				flag = TRUE;
		}
		//swap if need be
		if (first >= last) {
			flag = TRUE;
		} else {
			swap(&a[first], &a[last]);
		}
	}
	//place pivot in proper position
	swap(&a[left], &a[last]);

	return last;
}

void quick_sort(int *a, int left, int right) {
	if (right <= left) {
		return; //return if there are no elements in subarray
	}
	//split a[left...right] so that k is the pivot
	int k = partition(a, left, right);
	//elements from left to k-1 are less than or equal to k so sort them using the same method
	quick_sort(a, left, k - 1);
	//ements from k+1 to right are greater than or equal to k so sort them using the same method
	quick_sort(a, k + 1, right);
}

void swap(int *first, int *second) {
	int temp = *first;
	*first = *second;
	*second = temp;
	return;
}
