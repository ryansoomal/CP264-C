/*
 -------------------------------------
 File:    myrecord_llist.c
 Project: A5T1
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2021-02-25
 -------------------------------------
 */

// add your program signature
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "myrecord_llist.h"

void display(NODE *start) {
	NODE *np = start;
	while (np != NULL) {
		printf("%s,%.1f\n", np->data.name, np->data.score);
		np = (NODE*) np->next;
	}
}
/**
 * Search linked list for name key.
 * @param start Pointer to the first node of linked list.
 * @param name Key to search
 * @return Pointer to found node if found; otherwise NULL
 */
NODE* search(NODE *startp, char *name) {
	int is_found = 0;
	NODE *ptr = startp;
	while (ptr->next != NULL && is_found == 0) {
		if (strcmp(ptr->data.name, name) == 0) {
			is_found = 1;
		} else {
			ptr = (NODE*) ptr->next;
		}
	}
	if (is_found == 0) {
		ptr = NULL;
	}
	return ptr;
}
/**
 * Insert new record to linked list at the sorted position.
 * @param startp Pointer pointing to the start pointer of linked list, used to update the start node address in case of change.
 * @param name The name data of new record.
 * @param score The score data of new record
 */
void insert(NODE **startp, char *name, float score) {
	NODE *p = (NODE*) malloc(sizeof(NODE));
	strcpy(p->data.name, name);
	p->data.score = score;
	p->next = NULL;
	NODE *prev = NULL;
	NODE *ptr = *startp;
	while (ptr != NULL) {
		if (strcmp(ptr->data.name, name) >= 0) { //found the node
			break;
		} else {
			prev = ptr; //move to next
			ptr = (NODE*) ptr->next; //move to next
		}
	}

	if (prev == NULL) { //empty linked list or found at start
		*startp = p; //insert at begining
		p->next = ptr;
	} else { //found the node or not found, i.e. ptr = NULL
		prev->next = p; //insert between prev and ptr
		p->next = ptr;
	}

	return;
}
/**
 * Delete a record by name from linked list, the first one matched.
 * @param startp Pointer pointing to the start pointer of linked list, used to update the start node address in case of change.
 * @param name  The key used to find the node for deletion.
 * @return 1 if found and deleted; otherwise 0.
 */
int delete(NODE **startp, char *name) {
	//printf("%f", *startp->data.score);
	NODE *prev = NULL;
	NODE *ptr = *startp;
	int is_found = 0;
	//cases: first in list, prev will be null but is found will be 1
	//middle of list, prev will have a value and is found will be 1
	//end of list, ptr->next will be null and is found will be 1
	while (is_found == 0 && ptr != NULL) {
		if (strcmp(name, ptr->data.name) == 0) {
			is_found = 1;
		} else {
			prev = ptr;
			ptr = (NODE*) ptr->next;
		}
	}
	if (is_found == 1) {
		//first element
		if (prev == NULL) {
			(*startp) = (NODE*) (*startp)->next;
			free(ptr);
		}
		//middle
		else if (ptr->next != NULL) {
			prev->next = ptr->next;
			free(ptr);
		}
		//end of list
		else {
			prev->next = NULL;
			free(ptr);
		}
	}
	return is_found;

}
/**
 * Clean linked list.
 * @param startp Pointer pointing to the start pointer of linked list, used to update the start node address in case of change.
 */
void clean(NODE **startp) {
	NODE *ptr = *startp;
	NODE *next = NULL;
	while (ptr != NULL) {
		next = (NODE*) ptr->next;
		free(ptr);
		ptr = next;
	}
	*startp = NULL;
	return;
}

// the following functions are adapted and modified from previous assignments.

char letter_grade(float s) {
	char r = 'F';
	if (s >= 90)
		r = 'S';
	else if (s >= 80)
		r = 'A';
	else if (s >= 70)
		r = 'B';
	else if (s >= 60)
		r = 'C';
	else if (s >= 50)
		r = 'D';
	else
		r = 'F';
	return r;
}

int import_data(NODE **startp, char *filename) {
	char line[40], name[20];
	char *result = NULL;
	char delimiters[] = ",";
	float score = 0;
	int count = 0;

	FILE *fp = fopen(filename, "r");
	if (fp == NULL) {
		perror("Error while opening the file.\n");
		exit(EXIT_FAILURE);
	}

	while (fgets(line, sizeof(line), fp) != NULL) {
		result = strtok(line, delimiters);
		strcpy(name, result);
		result = strtok(NULL, delimiters);
		score = atof(result);
		insert(startp, name, score);
		count++;
	}
	fclose(fp);

	return count;
}

REPORT report_data(NODE *start, char *filename) {
	REPORT report = { };
	NODE *np = start;
	int count = 0;
	float mean = 0;
	float stddev = 0;

	FILE *fp = fopen(filename, "w");
	while (np != NULL) {
		count++;
		mean += np->data.score;
		stddev += np->data.score * np->data.score;
		fprintf(fp, "%s,%3.1f,%c\n", np->data.name, np->data.score,
				letter_grade(np->data.score));
		np = np->next;
	}
	fclose(fp);

	mean /= count;
	stddev = sqrt(stddev / count - mean * mean);
	report.count = count;
	report.mean = mean;
	report.stddev = stddev;
	return report;
}
