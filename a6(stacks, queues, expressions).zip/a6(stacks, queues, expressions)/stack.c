/*
 -------------------------------------
 File:    stack.c
 Project: A6T2
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2021-03-02
 -------------------------------------
 */

#include <stdio.h>
#include "stack.h"
#include <stdlib.h>

void push(STACK *sp, NODE *np) {
	np->next = sp->top;
	sp->top = np;
}

NODE* pop(STACK *sp) {
	NODE *popped = NULL;
	if (sp->top != NULL) {
		popped = sp->top;
		sp->top = popped->next;
		popped->next = NULL;
	}
	return popped;
}

void clean_stack(STACK *sp) {
	clean(&sp->top);
	/*
	 NODE *cur;
	 while (sp->top != NULL) {
	 cur = sp->top;
	 sp->top = sp->top->next;
	 free(cur);

	 }
	 sp->top = NULL;
	 */
}
