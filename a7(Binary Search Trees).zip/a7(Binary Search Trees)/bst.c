/*
 -------------------------------------
 File:    bst.c
 Project: A7T2
 file description
 -------------------------------------
 Author:  Ryan Soomal
 ID:      210370340
 Email:   soom0340@mylaurier.ca
 Version  2021-03-11
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "bst.h"
/* search bst by data.name matching the given name
 */
TNODE* search(TNODE *root, char *name) {
	while (root) {
		int compare = strcmp(name, root->data.name);
		if (compare == 0) {
			return root;
		} else if (compare == -1) {
			root = root->left;
		} else {
			root = root->right;
		}
	}

	return NULL;
}
/* insert record {name, score} into bst using data.name as key for comparison */
void insert(TNODE **rootp, char *name, float score) {
	RECORD new_record;
	new_record.score = score;
	strcpy(new_record.name, name);
	TNODE *newnp = (TNODE*) malloc(sizeof(TNODE));
	newnp->data = new_record;
	newnp->left = NULL;
	newnp->right = NULL;
	if (*rootp == NULL)
		*rootp = newnp;
	else {
		TNODE *p = *rootp;
		while (1) {
			int compare = strcmp(newnp->data.name, p->data.name);
			if (compare == 0) { //data already exists
				break;
			} else if (compare < 0) {
				if (p->left == NULL) {
					p->left = newnp;
					break;
				} else {
					p = p->left;
				}
			} else {
				if (p->right == NULL) {
					p->right = newnp;
					break;
				} else {
					p = p->right;
				}
			}

		}
	}
}
/* delete node of name.name from bst */
void delete(TNODE **rootp, char *name) {
	TNODE *tnp = *rootp, *ptnp = NULL, *smallest_node;

	//find the node
	while (tnp != NULL && strcmp(tnp->data.name, name) != 0) {
		ptnp = tnp;
		tnp = (strcmp(name, tnp->data.name) < 0) ? tnp->left : tnp->right;
	}
	if (tnp != NULL) { //nothing to do if the node doesn't exist
		//delete and rearrange nodes
		if (tnp->right == NULL) {
			if (ptnp == NULL) {
				*rootp = tnp->left;
			} else {
				if (ptnp->left == tnp)
					ptnp->left = tnp->left;
				else
					ptnp->right = tnp->left;
			}
		} else {
			smallest_node = extract_smallest_node(&tnp->right);
			if (ptnp == NULL) {
				*rootp = smallest_node;
			} else {
				if (ptnp->left == tnp)
					ptnp->left = smallest_node;
				else
					ptnp->right = smallest_node;
			}
			smallest_node->left = tnp->left;
			smallest_node->right = tnp->right;
		}
		//delete from memory
		free(tnp);

	}

}
/* get and return and delete the node of the smallest data.name node from the bst */
//unsure about the parent thing right now
TNODE* extract_smallest_node(TNODE **rootp) {
	if (*rootp == NULL) {
		return NULL;
	} else {
		TNODE *root = *rootp;
		TNODE *parent = NULL;
		while (root->left != NULL) {
			parent = root;
			root = root->left;
		}
		//bottom of tree
		parent->left = NULL;
		return root;
	}

}
/* display bst tree data by in-order */
void display_inorder(TNODE *root) {
	if (root) {
		if (root->left)
			display_inorder(root->left);
		printf("%-15s%3.1f\n", root->data.name, root->data.score);
		if (root->right)
			display_inorder(root->right);
	}
}
/* clean the tree */
void clean_tree(TNODE **rootp) {
	TNODE *root = *rootp;
	if (root) {
		if (root->left)
			clean_tree(&root->left);
		if (root->right)
			clean_tree(&root->right);
		free(root);
	}
	*rootp = NULL;
}
